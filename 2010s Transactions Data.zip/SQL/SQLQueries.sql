CREATE DATABASE TransactionsDB;
GO
USE TransactionsDB;

CREATE TABLE Users (
    id INT PRIMARY KEY,
    current_age INT,
    retirement_age INT,
    birth_year INT,
    birth_month INT,
    gender NVARCHAR(10),
    address NVARCHAR(255),
    latitude FLOAT,
    longitude FLOAT,
    per_capita_income DECIMAL(12,2),
    yearly_income DECIMAL(12,2),
    total_debt DECIMAL(12,2),
    credit_score INT,
    num_credit_cards INT
);

CREATE TABLE Cards (
    card_id INT PRIMARY KEY,
    client_id INT FOREIGN KEY REFERENCES Users(id),
    card_brand NVARCHAR(20),
    card_type NVARCHAR(30),
    card_number BIGINT,
    expires DATE,
    cvv INT,
    has_chip BIT,
    num_cards_issued INT,
    credit_limit DECIMAL(12,2),
    acct_open_date DATE,
    year_pin_last_changed INT,
    card_on_dark_web BIT
);

CREATE TABLE Transactions (
    transaction_id BIGINT PRIMARY KEY,
    transaction_date DATETIME,
    id INT FOREIGN KEY REFERENCES Users(id),
    card_id INT FOREIGN KEY REFERENCES Cards(card_id),
    amount DECIMAL(12,2),
    use_chip NVARCHAR(30),
    merchant_id INT,
    merchant_city NVARCHAR(100),
    merchant_state NVARCHAR(50),
    zip NVARCHAR(10),
    mcc INT,
    errors NVARCHAR(255)
);

CREATE TABLE MCC_Codes (
    mcc INT PRIMARY KEY,
    mcc_category NVARCHAR(255)
);

CREATE TABLE Fraud_Labels (
    transaction_id BIGINT PRIMARY KEY,
    fraud_label BIT,
    FOREIGN KEY (transaction_id) REFERENCES Transactions(transaction_id)
);

SELECT id, current_age, retirement_age from Users
SELECT COUNT(*) from Users

SELECT * from Cards

ALTER TABLE Cards
DROP COLUMN card_on_dark_web

SELECT mcc from Transactions

SELECT * from MCC_Codes

ALTER TABLE Transactions
ALTER COLUMN mcc int


--- new table for transactions
SELECT 
    t.*, 
    m.mcc_category
INTO 
    enriched_transactions
FROM 
    transactions AS t
LEFT JOIN 
    MCC_Codes AS m
ON 
    t.mcc = m.mcc

select mcc from Transactions
SELECT * FROM enriched_transactions

select * from Fraud_Labels

SELECT 
    t.*, 
    f.fraud_label
INTO 
    enriched_final_transactions
FROM 
    enriched_transactions AS t
LEFT JOIN 
    Fraud_Labels AS f
ON 
    t.transaction_id = f.transaction_id




BEGIN TRANSACTION -- CHECKPOINT

UPDATE enriched_final_transactions
SET errors = 'No Error'
WHERE errors IS NULL
SELECT errors FROM enriched_final_transactions

COMMIT

ROLLBACK

-- NULL count check
SELECT COUNT(*) AS null_count
FROM enriched_final_transactions
WHERE errors IS NULL;


SELECT * FROM Users




BEGIN TRANSACTION -- CHECKPOINT

UPDATE enriched_final_transactions
SET merchant_state = 'ONLINE'
WHERE merchant_state IS NULL
SELECT merchant_state FROM enriched_final_transactions

COMMIT

ROLLBACK


BEGIN TRANSACTION -- CHECKPOINT

UPDATE enriched_final_transactions
SET zip = 'ONLINE'
WHERE zip IS NULL
SELECT zip FROM enriched_final_transactions

COMMIT

ROLLBACK


